module.exports = {
    load: function () {
    },

    unload: function () {
    },

    'builder:open': function () {
        Editor.Panel.open('builder.panel');
    },
};
